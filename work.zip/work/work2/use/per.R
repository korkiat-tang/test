library(tidyverse)
library(readxl)
library(writexl)

base <- "H98:N517"
best <- "W98:AC517"
worst <- "AL98:AR517"
scenario <- c(base, best, worst)

all_scene <- data.frame()
for (s in scenario) {
  All_data <- read_excel("C:/Users/littl/Desktop/use/All data_V20.6.xlsx", sheet = "Per", range = s, col_names = FALSE)
  aaa <- as.data.frame(All_data[,1])
  aaa <- as.character(aaa[complete.cases(aaa),])
  lst <- list()
  for (i in 1:60) {
    lst[[aaa[i]]] <- matrix(as.numeric(as.matrix(All_data[(7*i-4):(7*i),3:7])), nrow = 5)
  }
  
  
  df <- as.data.frame(matrix(nrow = 24*4, ncol = 36))
  colnames(df) <- 1:36
  rownames(df) <- paste0(rep(aaa[1:24],each=4),"-",c("M0","M1","M2","M3"))
  for (i in 1:24) {
    mat <- lst[[aaa[i]]]
    df[(4*i-3):(4*i),1] <- mat[1:4,5]
    for (j in 2:36) {
      mat <- mat %*% lst[[aaa[i+j-1]]]
      df[(4*i-3):(4*i),j] <- mat[1:4,5]
    }
  }
  all_scene <- rbind(all_scene, df)
}

write_xlsx(all_scene, "C:/Users/littl/Desktop/use/per cpd.xlsx")